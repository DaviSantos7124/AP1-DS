﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EX1___CLASSES___CARRO
{
    class Carro
    {
        private string _placa_de_carro;
        private string _rodas;
        private string _modelo_carro;
        private string _motor_carro;

        public Carro()
        {
            this._placa_de_carro = null;
            this._rodas = null;
            this._modelo_carro = null;
            this._motor_carro = null;
        }

        public Carro(String novaPlacaCarro, String novaRodas, String novoModeloCarro, String novoMotorCarro)
        {
            this._placa_de_carro = novaPlacaCarro;
            this._rodas = novaRodas;
            this._modelo_carro = novoModeloCarro;
            this._motor_carro = novoMotorCarro;
        }

        public String get_placa_de_carro()
        {
            return this._placa_de_carro;
        }

        public void set_placa_de_carro(String novaPlacaCarro)
        {
            this._placa_de_carro = novaPlacaCarro;
        }

        public String get_rodas()
        {
            return this._rodas;
        }

        public void set_rodas(String novaRodas)
        {
            this._rodas = novaRodas;
        }

        public String get_modelo_carro()
        {
            return this._modelo_carro;
        }

        public void set_modelo_carro(String novoModeloCarro)
        {
            this._modelo_carro = novoModeloCarro;
        }

        public String get_motor_carro()
        {
            return this._motor_carro;
        }

        public void set_motor_carro(String novoMotorCarro)
        {
            this._motor_carro = novoMotorCarro;
        }
    }
}
