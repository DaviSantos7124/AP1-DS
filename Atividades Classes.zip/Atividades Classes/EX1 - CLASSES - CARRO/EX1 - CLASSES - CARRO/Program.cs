using System;

namespace EX1___CLASSES___CARRO
{
    class Program
    {
        static void Main(string[] args)
        {
            Carro c = new Carro();

            c.set_placa_de_carro("DA16VI0");
            c.set_rodas("4 Rodas");
            c.set_modelo_carro("Ferrari");
            c.set_motor_carro("V62GR");

            Console.WriteLine("=========== DADOS DO CARRO ===========");
            Console.WriteLine("Modelo: " + c.get_modelo_carro());
            Console.WriteLine("Placa : " + c.get_placa_de_carro());
            Console.WriteLine("Rodas : " + c.get_rodas());
            Console.WriteLine("Motor : " + c.get_motor_carro());

            Console.WriteLine("======================================");

            Console.WriteLine("=========== A��ES DO CARRO ===========");
            Console.WriteLine(c.Locomover());
            Console.WriteLine(c.Frear());

            Console.WriteLine("======================================");

            Console.ReadKey();
        }
    }
}