using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EX1___CLASSES___CARRO
{
    class Program
    {
        static void Main(string[] args)
        {
            Carro c = new Carro();

            c.set_placa_de_carro ("DA16VI0");
            c.set_rodas ("4 Rodas");
            c.set_modelo_carro ("Ferrari");
            c.set_motor_carro ("V62GR");

            Console.Write(string.Concat("O seu Carro é uma ", c.get_modelo_carro(), ", com a Placa: ", c.get_placa_de_carro(), 
                                                                ", Que contém ", c.get_rodas(), ", e tem um Motor: ", c.get_motor_carro()));

            Console.ReadKey();
        }   
    }
}
