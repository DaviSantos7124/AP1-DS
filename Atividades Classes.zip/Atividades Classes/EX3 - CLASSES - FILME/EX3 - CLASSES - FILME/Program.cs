using System;

namespace EX3___CLASSES___FILME
{
    class Program
    {
        static void Main(string[] args)
        {
            Filme f = new Filme();

            f.set_nome("Vingadores: Ultimato");
            f.set_roteirista("Christopher Markus e Stephen McFeely");
            f.set_atores("Robert Downey Jr., Chris Evans, Tom Holland");
            f.set_genero("Ação / Aventura");

            Console.WriteLine("===================== DADOS DO FILME ====================");
            Console.WriteLine("Nome        : " + f.get_nome());
            Console.WriteLine("Roteirista  : " + f.get_roteirista());
            Console.WriteLine("Atores      : " + f.get_atores());
            Console.WriteLine("Gênero      : " + f.get_genero());

            Console.WriteLine("=========================================================");

            Console.WriteLine("===================== AÇÕES DO FILME ====================");
            Console.WriteLine(f.Reproduzir());
            Console.WriteLine(f.Pausar());

            Console.WriteLine("=========================================================");

            Console.ReadKey();
        }
    }
}