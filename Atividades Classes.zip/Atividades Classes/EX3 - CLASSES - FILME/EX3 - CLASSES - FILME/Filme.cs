﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EX3___CLASSES___FILME
{
    class Filme
    {
        private string _roteirista;
        private string _nome;
        private string _atores;
        private string _genero;

        public Filme()
        {
            this._roteirista = null;
            this._nome = null;
            this._atores = null;
            this._genero = null;
        }

        public Filme(String novoRoteirista, String novoNome, String novosAtores, String novoGenero)
        {
            this._roteirista = novoRoteirista;
            this._nome = novoNome;
            this._atores = novosAtores;
            this._genero = novoGenero;
        }

        public String get_roteirista()
        {
            return this._roteirista;
        }

        public void set_roteirista(String novoRoteirista)
        {
            this._roteirista = novoRoteirista;
        }

        public String get_nome()
        {
            return this._nome;
        }

        public void set_nome(String novoNome)
        {
            this._nome = novoNome;
        }

        public String get_atores()
        {
            return this._atores;
        }

        public void set_atores(String novosAtores)
        {
            this._atores = novosAtores;
        }

        public String get_genero()
        {
            return this._genero;
        }

        public void set_genero(String novoGenero)
        {
            this._genero = novoGenero;
        }

        public string Reproduzir()
        {
            return "O filme " + this._nome + " está sendo reproduzido.";
        }

        public string Pausar()
        {
            return "O filme " + this._nome + " foi pausado.";
        }
    }
}