﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EX5___CLASSES___PACIENTE
{
    class Paciente
    {
        private string _nome;
        private string _sus;
        private string _rg;
        private string _sintomas;

        public Paciente()
        {
            this._nome = null;
            this._sus = null;
            this._rg = null;
            this._sintomas = null;
        }

        public Paciente(String novoNome, String novoSus, String novoRg, String novosSintomas)
        {
            this._nome = novoNome;
            this._sus = novoSus;
            this._rg = novoRg;
            this._sintomas = novosSintomas;
        }

        public String get_nome()
        {
            return this._nome;
        }

        public void set_nome(String novoNome)
        {
            this._nome = novoNome;
        }

        public String get_sus()
        {
            return this._sus;
        }

        public void set_sus(String novoSus)
        {
            this._sus = novoSus;
        }

        public String get_rg()
        {
            return this._rg;
        }

        public void set_rg(String novoRg)
        {
            this._rg = novoRg;
        }

        public String get_sintomas()
        {
            return this._sintomas;
        }

        public void set_sintomas(String novosSintomas)
        {
            this._sintomas = novosSintomas;
        }

        public string Diagnosticar()
        {
            return "O paciente " + this._nome + " está sendo diagnosticado.";
        }

        public string Medicar()
        {
            return "O paciente " + this._nome + " está sendo medicado.";
        }
    }
}