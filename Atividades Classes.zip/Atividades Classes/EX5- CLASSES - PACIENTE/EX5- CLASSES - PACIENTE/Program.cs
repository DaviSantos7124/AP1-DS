using System;

namespace EX5___CLASSES___PACIENTE
{
    class Program
    {
        static void Main(string[] args)
        {
            Paciente p = new Paciente();

            p.set_nome("João Lucas");
            p.set_sus("123456789");
            p.set_rg("45.678.912-3");
            p.set_sintomas("Passa vergonha e acha que é o protagonista");
            
            Console.WriteLine("================ - DADOS DO PACIENTE - ===================");

            Console.WriteLine("Nome       : " + p.get_nome());
            Console.WriteLine("SUS        : " + p.get_sus());
            Console.WriteLine("RG         : " + p.get_rg());
            Console.WriteLine("Sintomas   : " + p.get_sintomas());
            
            Console.WriteLine("================ - AÇÕES DO PACIENTE - ===================");

            Console.WriteLine(p.Diagnosticar());
            Console.WriteLine(p.Medicar());

            Console.WriteLine("==========================================================");

            Console.ReadKey();
        }
    }
}