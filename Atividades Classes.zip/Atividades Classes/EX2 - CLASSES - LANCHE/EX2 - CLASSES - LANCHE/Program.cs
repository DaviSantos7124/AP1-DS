using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EX2___CLASSES___LANCHE
{
    class Program
    {
        static void Main(string[] args)
        {
            Lanche l = new Lanche();

            l.set_ingrediente_lanche("1º Pão\n" +
                                     "2º Hamburguer\n" +
                                     "3º Mussarela\n" +
                                     "4º Presunto\n" +
                                     "5º Tomates\n" +
                                     "6º Alface");

            l.set_sabor_lanche("Salgado");
            l.set_tipo_lanche("Hamburguer");
            l.set_preço_lanche("R$ 21,00");

            Console.WriteLine("=========== - DADOS DO LANCHE - ============");

            Console.WriteLine("                          Ingredientes:");
            Console.WriteLine("                          1º Pão");
            Console.WriteLine("Tipo  : " + l.get_tipo_lanche() + "        2º Hamburguer");
            Console.WriteLine("Sabor : " + l.get_sabor_lanche() + "           3º Mussarela");
            Console.WriteLine("Preço : " + l.get_preço_lanche() + "          4º Presunto");
            Console.WriteLine("                          5º Tomates");
            Console.WriteLine("                          6º Alface");

            Console.WriteLine("============================================");
            
            Console.WriteLine("=========== - AÇÕES DO LANCHE - ============");
            Console.WriteLine(l.Preparar());
            Console.WriteLine(l.Servir());

            Console.WriteLine("============================================");

            Console.ReadKey();
        }
    }
}