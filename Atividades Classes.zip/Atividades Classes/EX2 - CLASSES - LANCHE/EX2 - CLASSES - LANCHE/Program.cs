using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EX2___CLASSES___LANCHE
{
    class Program
    {
        static void Main(string[] args)
        {
            Lanche l = new Lanche();

            l.set_ingrediente_lanche("1º Pão,\n" +
                                     "2º Hamburguer.\n" +
                                     "3º Mussarela.\n" +
                                     "4º Presunto.\n" +
                                     "5º Tomates.\n" +
                                     "6º Alface.");

            l.set_sabor_lanche("Salgado");
            l.set_tipo_lanche("Hamburguer");
            l.set_preço_lanche("R$ 21,00");

            Console.Write("================= - Tipo - ===================\n");

            Console.Write(string.Concat(l.get_tipo_lanche(), "\n"));

            Console.Write("================= - Sabor - ==================\n");

            Console.Write(string.Concat(l.get_sabor_lanche(), "\n"));

            Console.Write("============== - Ingredientes - ==============\n");

            Console.Write(string.Concat(l.get_ingrediente_lanche(), "\n"));

            Console.Write("================== - Preço - =================\n");

            Console.Write(string.Concat(l.get_preço_lanche(), "\n"));

            Console.Write("==============================================");

            Console.ReadKey();
        }
    }
}
