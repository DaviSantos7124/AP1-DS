﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EX2___CLASSES___LANCHE
{
    class Lanche
    {
        private string _ingrediente_lanche;
        private string _sabor_lanche;
        private string _tipo_lanche;
        private string _preço_lanche;

        public Lanche()
        {
            this._ingrediente_lanche = null;
            this._sabor_lanche = null;
            this._tipo_lanche = null;
            this._preço_lanche = null;
        }

        public Lanche(String novoIngredienteLanche, String novoSaborLanche, String novoTipoLanche, String novoPreçoLanche)
        {
            this._ingrediente_lanche = novoIngredienteLanche;
            this._sabor_lanche = novoSaborLanche;
            this._tipo_lanche = novoTipoLanche;
            this._preço_lanche = novoPreçoLanche;
        }

        public String get_ingrediente_lanche()
        {
            return this._ingrediente_lanche;
        }

        public void set_ingrediente_lanche(String novoIngredienteLanche)
        {
            this._ingrediente_lanche = novoIngredienteLanche;
        }

        public String get_sabor_lanche()
        {
            return this._sabor_lanche;
        }

        public void set_sabor_lanche(String novoSaborLanche)
        {
            this._sabor_lanche = novoSaborLanche;
        }

        public String get_tipo_lanche()
        {
            return this._tipo_lanche;
        }

        public void set_tipo_lanche(String novoTipoLanche)
        {
            this._tipo_lanche = novoTipoLanche;
        }

        public String get_preço_lanche()
        {
            return this._preço_lanche;
        }

        public void set_preço_lanche(String novoPreçoLanche)
        {
            this._preço_lanche = novoPreçoLanche;
        }
    }
}
