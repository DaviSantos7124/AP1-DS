using System;

namespace EX4___CLASSES___JOGADOR
{
    class Program
    {
        static void Main(string[] args)
        {
            Jogador j = new Jogador();

            j.set_nome("Hugo Calderano");
            j.set_time("Brasil");
            j.set_esporte("Tênis de Mesa (Ping Pong)");
            j.set_contrato("Contrato Olímpico");
            
            Console.WriteLine("================= - DADOS DO JOGADOR - ===================");

            Console.WriteLine("Nome       : " + j.get_nome());
            Console.WriteLine("Time       : " + j.get_time());
            Console.WriteLine("Esporte    : " + j.get_esporte());
            Console.WriteLine("Contrato   : " + j.get_contrato());
            
            Console.WriteLine("================= - AÇÕES DO JOGADOR - ===================");

            Console.WriteLine(j.Sacar());
            Console.WriteLine(j.Rebater());

            Console.WriteLine("==========================================================");

            Console.ReadKey();
        }
    }
}