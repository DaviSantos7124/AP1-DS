﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EX4___CLASSES___JOGADOR
{
    class Jogador
    {
        private string _nome;
        private string _time;
        private string _esporte;
        private string _contrato;

        public Jogador()
        {
            this._nome = null;
            this._time = null;
            this._esporte = null;
            this._contrato = null;
        }

        public Jogador(String novoNome, String novoTime, String novoEsporte, String novoContrato)
        {
            this._nome = novoNome;
            this._time = novoTime;
            this._esporte = novoEsporte;
            this._contrato = novoContrato;
        }

        public String get_nome()
        {
            return this._nome;
        }

        public void set_nome(String novoNome)
        {
            this._nome = novoNome;
        }

        public String get_time()
        {
            return this._time;
        }

        public void set_time(String novoTime)
        {
            this._time = novoTime;
        }

        public String get_esporte()
        {
            return this._esporte;
        }

        public void set_esporte(String novoEsporte)
        {
            this._esporte = novoEsporte;
        }

        public String get_contrato()
        {
            return this._contrato;
        }

        public void set_contrato(String novoContrato)
        {
            this._contrato = novoContrato;
        }

        public string Sacar()
        {
            return "O jogador " + this._nome + " realizou o saque.";
        }

        public string Rebater()
        {
            return "O jogador " + this._nome + " rebateu a bola.";
        }
    }
}